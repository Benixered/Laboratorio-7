package sample;

public class Productos{
    private String Articulo;
    private int Cantidad;
    private double Unitario;
    private double Total;
    private String Estado;


    public Productos(){
        this.Articulo = "";
        this.Cantidad = 0;
        this.Unitario = 0;
        this.Total = 0;
        this.Estado = "";

    }

    public Productos(String Articulo, int Cantidad, double Unitario, double Total, String Estado){
        this.Articulo = Articulo;
        this.Cantidad = Cantidad;
        this.Unitario = Unitario;
        this.Total = Total;
        this.Estado = Estado;

    }

    public String getArticulo() {
        return Articulo;
    }

    public void setArticulo(String Articulo) {
        this.Articulo = Articulo;
    }


    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public double getUnitario() {
        return Unitario;
    }

    public void setUnitario(double Unitario) {
        this.Unitario = Unitario;
    }

    public double getTotal() {
        return Total;
    }

    public void setTotal(double Total) {
        this.Total = Total;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }




}

