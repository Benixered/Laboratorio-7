package sample;

public class Controller {
    public static class Producto {
    }
}
