package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import sample.Controller;
import sample.Productos;

public class Main extends Application {

    Stage window;
    TableView<Productos> table;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        window.setTitle("Mi lista 1");

        //Columna de nombres
        TableColumn<Productos, String> columnaArticulo = new TableColumn<>("Articulo");
        columnaArticulo.setMinWidth(200);
        columnaArticulo.setCellValueFactory(new PropertyValueFactory<>("Articulo"));

        //Cantidades
        TableColumn<Productos, String> ColumnaCantidad = new TableColumn<>("Cantidad");
        ColumnaCantidad.setMinWidth(100);
        ColumnaCantidad.setCellValueFactory(new PropertyValueFactory<>("Cantidad"));

        //Precios
        TableColumn<Productos, Double> ColumnaUnitario = new TableColumn<>("Unitario");
        ColumnaUnitario.setMinWidth(100);
        ColumnaUnitario.setCellValueFactory(new PropertyValueFactory<>("Unitario"));

        TableColumn<Productos, Double> ColumnaTotal = new TableColumn<>("Total");
        ColumnaTotal.setMinWidth(100);
        ColumnaTotal.setCellValueFactory(new PropertyValueFactory<>("Total"));

        //Estado del producto
        TableColumn<Productos, String> columnaEstado = new TableColumn<>("Estado");
        columnaEstado.setMinWidth(200);
        columnaEstado.setCellValueFactory(new PropertyValueFactory<>("Estado"));


//┻━┻ ︵ ＼( °□° )／ ︵ ┻━┻
        table = new TableView<>();
        table.setItems(getProducto());
        table.getColumns().addAll(columnaArticulo, ColumnaCantidad, ColumnaUnitario, ColumnaTotal, columnaEstado );

        VBox vBox = new VBox();
        vBox.getChildren().addAll(table);

        Scene escena = new Scene(vBox);
        window.setScene(escena);
        window.show();
    }

    //lista de productos
    public ObservableList<Productos> getProducto(){
        ObservableList<Productos> productos = FXCollections.observableArrayList();

        productos.add(new Productos("Mouse", 2, 6.99, 13.98, "Pendiente" ));
        return productos;
    }


}